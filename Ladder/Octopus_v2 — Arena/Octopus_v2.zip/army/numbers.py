import sc2


class Numbers:
    def __init__(self, ai: sc2.BotAI):
        self.ai = ai

    def count_numbers(self):
        pass

    def times_are_good(self):
        pass